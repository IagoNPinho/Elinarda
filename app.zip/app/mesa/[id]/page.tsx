"use client"

import { useEffect } from "react"
import { UtensilsCrossed } from "lucide-react"
import { MenuItemCard } from "@/components/menu-item-card"
import { CartBar } from "@/components/cart-bar"
import { useCart } from "@/components/cart-provider"
import { menuItems, categories } from "@/lib/menu-data"

interface PageProps {
  params: { id: string }
}

export default function TableMenuPage({ params }: PageProps) {
  const { id } = params
  const tableNumber = Number.parseInt(id, 10)
  const { setTableNumber } = useCart()

  useEffect(() => {
    setTableNumber(tableNumber)
  }, [tableNumber, setTableNumber])

  return (
    <main className="min-h-screen bg-background pb-28">
      <header className="sticky top-0 bg-primary text-primary-foreground p-4 shadow-md z-10">
        <div className="max-w-2xl mx-auto flex items-center gap-3">
          <div className="w-10 h-10 bg-primary-foreground/20 rounded-full flex items-center justify-center">
            <UtensilsCrossed className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-xl font-bold">Restaurante</h1>
            <p className="text-sm opacity-90">Mesa {tableNumber}</p>
          </div>
        </div>
      </header>

      <div className="max-w-2xl mx-auto p-4 space-y-8">
        {categories.map((category) => (
          <section key={category}>
            <h2 className="text-2xl font-bold mb-4">{category}</h2>
            <div className="space-y-4">
              {menuItems
                .filter((item) => item.category === category)
                .map((item) => (
                  <MenuItemCard key={item.id} item={item} />
                ))}
            </div>
          </section>
        ))}
      </div>

      <CartBar />
    </main>
  )
}
