"use client"

import { useParams, useRouter } from "next/navigation"
import { ArrowLeft, FileText } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useCart } from "@/components/cart-provider"
import { generateOrderPDF } from "@/lib/generate-order-pdf"

export default function KitchenOrderDetailPage() {
  const { id } = useParams()
  const router = useRouter()
  const { orders } = useCart()

  const order = orders.find(
    (o) => o.id === Number(id),
  )

  if (!order) {
    return (
      <main className="p-4">
        <p>Pedido não encontrado.</p>
        <Button onClick={() => router.push("/cozinha")}>
          Voltar
        </Button>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-background p-4">
      <header className="flex items-center gap-3 mb-6">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => router.push("/cozinha")}
        >
          <ArrowLeft />
        </Button>
        <h1 className="text-xl font-bold">
          Pedido #{order.id}
        </h1>
      </header>

      <div className="space-y-4">
        <p className="text-sm">Mesa {order.mesa}</p>

        <ul className="border rounded-lg p-4 space-y-2">
          {order.items.map((item) => (
            <li key={item.id}>
              {item.quantity}x {item.name}
            </li>
          ))}
        </ul>

        <p className="font-bold text-lg">
          Total: R$ {order.total.toFixed(2)}
        </p>

        <Button
          onClick={() => generateOrderPDF(order)}
          className="w-full flex gap-2"
        >
          <FileText className="w-5 h-5" />
          Gerar PDF do Pedido
        </Button>
      </div>
    </main>
  )
}
