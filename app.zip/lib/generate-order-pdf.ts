import jsPDF from "jspdf"
import type { Order } from "@/components/cart-provider"

export function generateOrderPDF(order: Order) {
  const doc = new jsPDF({
    orientation: "portrait",
    unit: "mm",
    format: [80, 200], // largura tipo impressora térmica
  })

  let y = 10

  doc.setFontSize(12)
  doc.text(`Pedido #${order.id}`, 10, y)
  y += 6

  doc.setFontSize(10)
  doc.text(`Mesa: ${order.mesa}`, 10, y)
  y += 6

  doc.text("--------------------------", 10, y)
  y += 6

  order.items.forEach((item) => {
    doc.text(
      `${item.quantity}x ${item.name}`,
      10,
      y,
    )
    y += 5
  })

  y += 4
  doc.text("--------------------------", 10, y)
  y += 6

  doc.setFontSize(12)
  doc.text(`Total: R$ ${order.total.toFixed(2)}`, 10, y)

  doc.save(`pedido-${order.id}.pdf`)
}