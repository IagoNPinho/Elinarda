export interface MenuItem {
  id: string
  name: string
  description: string
  sizes: {
    size: "P" | "G" | "U"
    label: string
    price: number
  }[]
  category: string
}

export const menuItems: MenuItem[] = [
  {
    id: "1",
    name: "Hambúrguer Clássico",
    description: "Pão, carne 150g, queijo, alface, tomate e molho especial",
    sizes: [
      { size: "P", label: "Pequeno", price: 22.9 },
      { size: "G", label: "Grande", price: 29.9 },
    ],
    category: "Hambúrgueres",
  },
  {
    id: "2",
    name: "Hambúrguer Bacon",
    description: "Pão, carne 150g, queijo, bacon crocante e cebola caramelizada",
    sizes: [
      { size: "P", label: "Pequeno", price: 26.9 },
      { size: "G", label: "Grande", price: 34.9 },
    ],
    category: "Hambúrgueres",
  },
  {
    id: "3",
    name: "Batata Frita",
    description: "Batatas fritas crocantes com sal e temperos",
    sizes: [
      { size: "P", label: "Pequena", price: 12.9 },
      { size: "G", label: "Grande", price: 18.9 },
    ],
    category: "Acompanhamentos",
  },
  {
    id: "4",
    name: "Onion Rings",
    description: "Anéis de cebola empanados e fritos",
    sizes: [{ size: "U", label: "Única", price: 16.9 }],
    category: "Acompanhamentos",
  },
  {
    id: "5",
    name: "Refrigerante",
    description: "Coca-Cola, Guaraná ou Sprite",
    sizes: [
      { size: "P", label: "300ml", price: 6.9 },
      { size: "G", label: "600ml", price: 9.9 },
    ],
    category: "Bebidas",
  },
  {
    id: "6",
    name: "Suco Natural",
    description: "Laranja, limão ou maracujá",
    sizes: [
      { size: "P", label: "300ml", price: 8.9 },
      { size: "G", label: "500ml", price: 12.9 },
    ],
    category: "Bebidas",
  },
  {
    id: "7",
    name: "Milk Shake",
    description: "Chocolate, morango ou baunilha",
    sizes: [
      { size: "P", label: "300ml", price: 14.9 },
      { size: "G", label: "500ml", price: 19.9 },
    ],
    category: "Sobremesas",
  },
  {
    id: "8",
    name: "Brownie",
    description: "Brownie de chocolate com sorvete",
    sizes: [{ size: "U", label: "Única", price: 16.9 }],
    category: "Sobremesas",
  },
]

export const categories = [...new Set(menuItems.map((item) => item.category))]
